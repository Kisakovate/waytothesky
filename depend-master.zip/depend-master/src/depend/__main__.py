"""Support executing module as script"""
from .cli import app

app()
