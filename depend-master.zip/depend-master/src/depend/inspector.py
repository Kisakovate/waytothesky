"""License & Version Extractor"""
import re
from typing import Tuple

from depend.constants import REGISTRY
from depend.dependencies.dep_types import Result
from depend.error import LanguageNotSupportedError, VCSNotSupportedError
from depend.vcs.github_worker import handle_github


def handle_vcs(
    language: str,
    dependency: str,
    result: Result,
) -> None:
    """
    Fall through to VCS check for a go namespace (only due to go.mod check)
    :param language: primary language of the package
    :param dependency: package not found in other repositories
    :param result: object with name version license and dependencies
    """
    if "github.com" in dependency:
        handle_github(language, dependency, result)
    else:
        raise VCSNotSupportedError(dependency)


def make_url(language: str, package: str, version: str = "") -> str:
    """
    Construct the API JSON request URL or web URL to scrape
    :param language: lowercase: python, javascript or go
    :param package: as imported in source
    :param version: optional version specification
    :return: url to fetch
    """
    suffix = ""
    url_elements: Tuple[str, ...]
    match language:
        case "python":
            if version:
                url_elements = (
                    str(REGISTRY[language]["url"]),
                    package,
                    version,
                    "json",
                )
            else:
                url_elements = (str(REGISTRY[language]["url"]), package, "json")
        case "javascript":
            if version:
                url_elements = (str(REGISTRY[language]["url"]), package, version)
            else:
                url_elements = (str(REGISTRY[language]["url"]), package)
        case "go":
            if version:
                url_elements = (str(REGISTRY[language]["url"]), package + "@" + version)
            else:
                url_elements = (str(REGISTRY[language]["url"]), package)
        case "cs":
            # Repository expects package name to be lowercase for it to work reliably
            package = package.lower()
            if version:
                url_elements = (
                    REGISTRY[language]["url"],
                    package,
                    version,
                    package + ".nuspec",
                )
            else:
                url_elements = (REGISTRY[language]["url"], package, "index.json")
        case "php":
            url_elements = (REGISTRY[language]["url"], package)
            suffix = ".json"
        case "rust":
            if version:
                url_elements = (REGISTRY[language]["url"], package, version)
            else:
                url_elements = (REGISTRY[language]["url"], package, "versions")
        case _:
            raise LanguageNotSupportedError(language)
    return "/".join(url_elements).rstrip("/") + suffix


def find_github(text: str) -> str:
    """
    Returns a repo url from a string
    :param text: string to check
    """
    repo_identifier = re.search(
        r"github.com/([^/]+)/([^/.\r\n]+)(?:/tree/|)?([^/.,\s\r\n]+)?", text
    )
    if repo_identifier:
        return (
            "https://github.com/"
            + repo_identifier.group(1)
            + "/"
            + repo_identifier.group(2)
        )
    else:
        return ""
