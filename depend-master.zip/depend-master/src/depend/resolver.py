"""
Async Resolver
Takes Lang Package & Version Constraint
Returns Result Object with final constraints and obtained data
"""
import asyncio
from datetime import datetime
from typing import List, Optional, Set, Tuple

import httpx
from loguru import logger

from depend.dependencies.dep_types import Result
from depend.dependencies.helper import (
    fix_constraint,
    go_versions,
    handle_cs,
    handle_npmjs,
    handle_php,
    handle_pypi,
    handle_rust,
    js_versions,
    nuget_versions,
    parse_dep_response,
    php_versions,
    py_versions,
    resolve_version,
    rust_versions,
    scrape_go,
)
from depend.error import VCSNotSupportedError
from depend.inspector import find_github, handle_vcs, make_url


async def make_single_request(
    language: str,
    package: str,
    version: str = "",
    client=None,
    all_ver: bool = False,
) -> Tuple[str, str, List[str]]:
    """
    Resolve vers
    :param language: python, javascript or go
    :param package: as imported
    :param version: check for specific version
    :param client: httpx async client
    :param all_ver: all versions queried if version not supplied
    :return: result object with name version license and dependencies
    """
    vers = []
    supported_domains = [
        "github.com",
    ]
    # Single request is meant to be handled by VCS provider
    if any(domain in version for domain in supported_domains):
        if "||" in version:
            git_url, git_branch = version.split("||")
            repo = git_url + "/tree/" + git_branch
        else:
            repo = version
        vers = [repo]
    # Requested for a version using a version constraint
    else:
        version_constraints = fix_constraint(language, version)
        logger.debug(
            "(Analysing {}|{}) Converted {} to pythonic version constraints: {}",
            language,
            package,
            version,
            list(map(str, version_constraints)),
        )
        url = make_url(language, package)
        # Get all available versions for specified package
        response = await client.get(url)
        red_url = url
        match language:
            case "python":
                vers = py_versions(response)
            case "javascript":
                vers = js_versions(response)
            case "go":
                if response.status_code == 200:
                    # Handle 302: Redirection
                    if response.history:
                        red_url = response.url
                vers = go_versions(red_url)
            case "cs":
                vers = nuget_versions(response)
            case "php":
                vers = php_versions(response)
            case "rust":
                vers = rust_versions(response)
        if response.status_code != 200:
            logger.error(
                "{}: Queried {} for version list", response.status_code, red_url
            )
        # Parse only one version resolved from constraint provided
        if not all_ver and vers:
            resolved_version = resolve_version(vers, version_constraints)
            if resolved_version is not None:
                logger.debug(
                    "(Analysing {}|{}) Resolved version {} from available versions: {} using constraints {}",
                    language,
                    package,
                    resolved_version,
                    vers,
                    list(map(str, version_constraints)),
                )

                vers = [resolved_version]
            else:
                vers = []
                logger.warning(
                    f"No version could be resolved for package {package} with version constraint {version}"
                )
    return language, package, vers


async def work_with_vers(
    language: str,
    package: str,
    vers: list,
    client=None,
    force_schema: bool = True,
) -> Tuple[dict | Result | List[Result], Set[str]]:
    """
    Obtain package license and dependency information.
    :param language: python, javascript or go
    :param package: as imported
    :param vers: check for specific versions
    :param client: httpx async client
    :param force_schema: returns schema compliant response if true
    """
    rem_dep: Set[str] = set()
    result_list = []
    result: Result = {
        "import_name": "",
        "lang_ver": [],
        "pkg_name": package,
        "pkg_ver": "",
        "pkg_lic": ["Other"],
        "pkg_err": {},
        "pkg_dep": [],
        "timestamp": datetime.utcnow().isoformat(),
    }
    repo = ""
    # Check multiple versions of specified package
    for ver in vers:
        # Construct URL for version specific data
        url = make_url(language, package, ver)
        response = await client.get(url)
        red_url = url
        # Collect repo if available to do vcs query if data incomplete
        match language:
            case "python":
                repo = handle_pypi(response, result)
            case "javascript":
                repo = handle_npmjs(response, result)
            case "cs":
                repo = handle_cs(response, result)
            case "php":
                handle_php(response, result, ver)
            case "rust":
                handle_rust(response, result, url)
            case "go":
                if response.status_code == 200:
                    if response.history:
                        red_url = str(response.url) + "@" + ver
                        response = await client.get(red_url)
                    scrape_go(response, result, red_url)
                elif not repo:
                    repo = package
        if repo:
            try:
                handle_vcs(language, repo, result)
            except VCSNotSupportedError:
                logger.info(f"Unable to use VCS as unsupported: {repo}")
        else:
            if response.status_code != 200:
                logger.error(
                    f"{response.status_code}: {url} maybe git: {find_github(response.text)}"
                )
        rem_dep = set(result.get("pkg_dep") or [])
        result_list.append(result)
    if not result_list:
        result_list = [result]
    if force_schema:
        return parse_dep_response(result_list), rem_dep
    else:
        return result_list, rem_dep


async def make_multiple_requests(
    language: str,
    packages: List[str],
    depth: Optional[int] = None,
    result: Optional[dict] = None,
) -> dict:
    """
    Obtain license and dependency information for list of packages.
    :param language: python, javascript or go
    :param packages: a list of dependencies in each language
    :param depth: depth of recursion, None for no limit and 0 for input parsing alone
    :param result: optional result object to append to during recursion
    :return: result object with name version license and dependencies
    """
    return await _make_multiple_requests(
        language,
        packages,
        depth,
        result,
        _already_queried=set(),
    )


async def _make_multiple_requests(
    language: str,
    packages: List[str],
    depth: Optional[int] = None,
    result: Optional[dict] = None,
    _already_queried: Optional[Set] = None,
) -> dict:
    """
    Recursive implementation of make_multiple_requests, with caching.
    :param _already_queried: set that keeps track of queried packages
    """
    if result is None:
        result = {}
    deps = set()
    limits = httpx.Limits(max_keepalive_connections=None, max_connections=None, keepalive_expiry=None)
    async with httpx.AsyncClient(follow_redirects=True, limits=limits) as client:
        resolved_vers = []
        for package_d in packages:
            name_ver = package_d.rsplit(";", 1)
            if len(name_ver) == 1:
                resolved_vers.append(
                    asyncio.ensure_future(
                        make_single_request(language, name_ver[0], client=client)
                    )
                )
            else:
                resolved_vers.append(
                    asyncio.ensure_future(
                        make_single_request(
                            language, name_ver[0], name_ver[1], client=client
                        )
                    )
                )
            _already_queried.add(package_d)
        resolved_deps = await asyncio.gather(*resolved_vers)
        tasks = []
        for lang, pack, vers in resolved_deps:
            if pack in result:
                unfetched_vers = list(filter(lambda ver: ver not in result[pack], vers))
            else:
                unfetched_vers = vers
            if unfetched_vers:
                tasks.append(
                    asyncio.ensure_future(
                        work_with_vers(lang, pack, unfetched_vers, client)
                    )
                )
        final_results = await asyncio.gather(*tasks)
        for dep_resp, res_deps in final_results:
            for package, ver_info in dep_resp.items():
                result[package] = ver_info["versions"]
            deps = deps.union(res_deps)
        deps.difference_update(_already_queried)
        # higher levels may ignore version specifications
        if len(deps) > 0 and depth is None:
            logger.debug("Invoking multiple requests for list: {}", list(deps))
            return await _make_multiple_requests(
                language, list(deps), result=result, _already_queried=_already_queried
            )
        elif len(deps) > 0 and isinstance(depth, int) and depth > 0:
            logger.debug(
                "({} Until Recursion Limit) Invoking multiple requests for list: {}",
                depth,
                list(deps),
            )
            logger.debug("Invoking multiple requests for {}", list(deps))
            return await _make_multiple_requests(
                language, list(deps), depth - 1, result, _already_queried
            )
        else:
            logger.debug("Exiting recursion with remaining depth {}", depth)
            return result
