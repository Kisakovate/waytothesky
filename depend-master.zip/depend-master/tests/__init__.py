"""Prevent this directory from being basedir"""
