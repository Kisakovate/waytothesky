"""Tests output obtained by parsing dependency files"""
import pytest
from deepdiff import DeepDiff
from jsonschema import validate

import depend.dependencies.cs.cs_worker as cs_worker
import depend.dependencies.go.go_worker as go_worker
import depend.dependencies.js.js_worker as js_worker
import depend.dependencies.php.php_worker as php_worker
import depend.dependencies.py.py_helper as py_helper
import depend.dependencies.py.py_worker as py_worker
import depend.dependencies.rust.rust_worker as rust_worker


class Helpers:
    """Helpers for test"""

    @staticmethod
    def is_valid(json_list):
        """Sets up schema check"""
        j_schema = {
            "type": "object",
            "properties": {
                "lang_ver": {"type": "array", "items": {"type": "string"}},
                "pkg_name": {"type": "string"},
                "pkg_ver": {"type": "string"},
                "pkg_dep": {
                    "anyOf": [
                        {"type": "array", "items": {"type": "string"}},
                        {"type": "null"},
                    ]
                },
                "pkg_err": {"type": "object"},
                "pkg_lic": {"type": "array", "items": {"type": "string"}},
                "timestamp": {"type": "string"},
            },
        }
        validate(instance=json_list, schema=j_schema)
        return True


@pytest.fixture
def json_schema():
    """Schema helper functions"""
    return Helpers


def test_go_mod(json_schema):
    """Check go.mod file output"""
    with open("tests/data/example_go.mod") as f:
        mod_content = f.read()
    result = go_worker.handle_go_mod(mod_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [""],
            "pkg_name": "github.com/skyrocknroll/go-mod-example",
            "pkg_ver": "",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "github.com/alecthomas/template;v0.0.0-20160405071501-a0175ee3bccc",
                "github.com/alecthomas/units;v0.0.0-20151022065526-2efee857e7cf",
                "github.com/gorilla/mux;v1.6.2",
                "github.com/sirupsen/logrus;v1.2.0",
                "gopkg.in/alecthomas/kingpin.v2;v2.2.6",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_package_json(json_schema):
    """Check package.json file output"""
    with open("tests/data/example_package.json") as f:
        json_content = f.read()
    result = js_worker.handle_json(json_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [""],
            "pkg_name": "",
            "pkg_ver": "1.0.0",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "jshint;latest",
                "imagemin;latest",
                "browser-sync;latest",
                "uglifyjs;latest",
                "watch;latest",
                "cssmin;latest",
                "jscs;latest",
                "uglify-js;latest",
                "browserify;latest",
                "expect.js;latest",
                "should;latest",
                "mocha;latest",
                "istanbul;latest",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_npm_shrinkwrap_json(json_schema):
    """Check package.json file output"""
    with open("tests/data/example_npm_shrinkwrap.json") as f:
        json_content = f.read()
    result = js_worker.handle_json(json_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [""],
            "pkg_name": "",
            "pkg_ver": "0.0.1",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "grunt-ember-handlebars;0.7.0",
                "grunt;0.4.1",
                "async;0.1.22",
                "coffee-script;1.3.3",
                "colors;0.6.2",
                "dateformat;1.0.2-1.2.3",
                "eventemitter2;0.4.13",
                "findup-sync;0.1.2",
                "lodash;1.0.1",
                "glob;3.1.21",
                "graceful-fs;1.2.3",
                "inherits;1.0.0",
                "hooker;0.2.3",
                "iconv-lite;0.2.11",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "nopt;1.0.10",
                "abbrev;1.0.4",
                "rimraf;2.0.3",
                "graceful-fs;1.1.14",
                "lodash;0.9.2",
                "underscore.string;2.2.1",
                "which;1.0.5",
                "js-yaml;2.0.5",
                "argparse;0.1.15",
                "underscore;1.4.4",
                "underscore.string;2.3.3",
                "esprima;1.0.4",
                "grunt-lib-contrib;0.5.3",
                "zlib-browserify;0.0.1",
                "lineman;0.15.0",
                "grunt;0.4.1",
                "async;0.1.22",
                "coffee-script;1.3.3",
                "colors;0.6.2",
                "dateformat;1.0.2-1.2.3",
                "eventemitter2;0.4.13",
                "findup-sync;0.1.2",
                "lodash;1.0.1",
                "glob;3.1.21",
                "graceful-fs;1.2.3",
                "inherits;1.0.0",
                "hooker;0.2.3",
                "iconv-lite;0.2.11",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "nopt;1.0.10",
                "abbrev;1.0.4",
                "rimraf;2.0.3",
                "graceful-fs;1.1.14",
                "lodash;0.9.2",
                "underscore.string;2.2.1",
                "which;1.0.5",
                "js-yaml;2.0.5",
                "argparse;0.1.15",
                "underscore;1.4.4",
                "underscore.string;2.3.3",
                "esprima;1.0.4",
                "grunt-contrib-clean;0.5.0",
                "rimraf;2.2.2",
                "graceful-fs;2.0.1",
                "grunt-contrib-coffee;0.7.0",
                "grunt-contrib-concat;0.3.0",
                "grunt-contrib-copy;0.4.1",
                "grunt-contrib-handlebars;0.5.10",
                "handlebars;1.0.12",
                "optimist;0.3.7",
                "wordwrap;0.0.2",
                "uglify-js;2.3.6",
                "async;0.2.9",
                "source-map;0.1.31",
                "amdefine;0.1.0",
                "grunt-lib-contrib;0.5.3",
                "zlib-browserify;0.0.1",
                "grunt-contrib-jshint;0.6.4",
                "jshint;2.1.11",
                "shelljs;0.1.4",
                "underscore;1.4.4",
                "cli;0.4.5",
                "glob;3.2.6",
                "inherits;2.0.1",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "console-browserify;0.1.6",
                "grunt-contrib-jst;0.5.1",
                "lodash;1.0.1",
                "grunt-lib-contrib;0.5.3",
                "zlib-browserify;0.0.1",
                "grunt-contrib-less;0.7.0",
                "less;1.4.2",
                "mime;1.2.11",
                "request;2.27.0",
                "qs;0.6.5",
                "json-stringify-safe;5.0.0",
                "forever-agent;0.5.0",
                "tunnel-agent;0.3.0",
                "http-signature;0.10.0",
                "assert-plus;0.1.2",
                "asn1;0.1.11",
                "ctype;0.5.2",
                "hawk;1.0.0",
                "hoek;0.9.1",
                "boom;0.4.2",
                "cryptiles;0.2.2",
                "sntp;0.2.4",
                "aws-sign;0.3.0",
                "oauth-sign;0.3.0",
                "cookie-jar;0.3.0",
                "node-uuid;1.4.1",
                "form-data;0.1.2",
                "combined-stream;0.0.4",
                "delayed-stream;0.0.5",
                "async;0.2.9",
                "mkdirp;0.3.5",
                "ycssmin;1.0.1",
                "grunt-lib-contrib;0.6.1",
                "zlib-browserify;0.0.1",
                "grunt-contrib-sass;0.5.0",
                "dargs;0.1.0",
                "grunt-contrib-cssmin;0.6.1",
                "clean-css;1.0.12",
                "grunt-lib-contrib;0.6.1",
                "zlib-browserify;0.0.1",
                "grunt-contrib-uglify;0.2.4",
                "uglify-js;2.4.1",
                "async;0.2.9",
                "source-map;0.1.31",
                "amdefine;0.1.0",
                "optimist;0.3.7",
                "wordwrap;0.0.2",
                "uglify-to-browserify;1.0.1",
                "grunt-lib-contrib;0.6.1",
                "zlib-browserify;0.0.1",
                "grunt-watch-nospawn;0.0.3",
                "gaze;0.3.3",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "fileset;0.1.5",
                "glob;3.2.6",
                "inherits;2.0.1",
                "config-extend;0.0.6",
                "testem;0.5.3",
                "express;3.1.0",
                "connect;2.7.2",
                "qs;0.5.1",
                "formidable;1.0.11",
                "bytes;0.1.0",
                "pause;0.0.1",
                "commander;0.6.1",
                "range-parser;0.0.4",
                "mkdirp;0.3.3",
                "cookie;0.0.5",
                "buffer-crc32;0.1.1",
                "fresh;0.1.0",
                "methods;0.0.1",
                "send;0.1.0",
                "mime;1.2.6",
                "cookie-signature;0.0.1",
                "debug;0.7.2",
                "mustache;0.4.0",
                "socket.io;0.9.16",
                "socket.io-client;0.9.16",
                "uglify-js;1.2.5",
                "ws;0.4.31",
                "commander;0.6.1",
                "nan;0.3.2",
                "tinycolor;0.0.1",
                "options;0.0.5",
                "xmlhttprequest;1.4.2",
                "active-x-obfuscator;0.0.1",
                "zeparser;0.0.5",
                "policyfile;0.0.4",
                "base64id;0.1.0",
                "redis;0.7.3",
                "winston;0.7.2",
                "cycle;1.0.2",
                "eyes;0.1.8",
                "pkginfo;0.3.0",
                "request;2.16.6",
                "form-data;0.0.10",
                "combined-stream;0.0.4",
                "delayed-stream;0.0.5",
                "mime;1.2.11",
                "hawk;0.10.2",
                "hoek;0.7.6",
                "boom;0.3.8",
                "cryptiles;0.1.3",
                "sntp;0.1.4",
                "node-uuid;1.4.1",
                "cookie-jar;0.2.0",
                "aws-sign;0.2.0",
                "oauth-sign;0.2.0",
                "forever-agent;0.2.0",
                "tunnel-agent;0.2.0",
                "json-stringify-safe;3.0.0",
                "qs;0.5.6",
                "stack-trace;0.0.7",
                "charm;0.0.8",
                "js-yaml;2.1.3",
                "argparse;0.1.15",
                "underscore;1.4.4",
                "underscore.string;2.3.3",
                "esprima;1.0.4",
                "tap;0.4.4",
                "inherits;2.0.0",
                "yamlish;0.0.5",
                "slide;1.1.5",
                "runforcover;0.0.2",
                "bunker;0.1.2",
                "burrito;0.2.12",
                "traverse;0.5.2",
                "uglify-js;1.1.1",
                "nopt;2.1.2",
                "abbrev;1.0.4",
                "mkdirp;0.3.5",
                "difflet;0.2.6",
                "traverse;0.6.6",
                "charm;0.1.2",
                "deep-is;0.1.2",
                "deep-equal;0.0.0",
                "buffer-equal;0.0.0",
                "glob;3.2.6",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "inherits;2.0.1",
                "glob;3.1.21",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "graceful-fs;1.2.3",
                "inherits;1.0.0",
                "async;0.2.9",
                "rimraf;2.2.2",
                "graceful-fs;2.0.1",
                "backbone;1.0.0",
                "underscore;1.5.2",
                "styled_string;0.0.1",
                "colors;0.6.2",
                "fileset;0.1.5",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "growl;1.7.0",
                "consolidate;0.8.0",
                "did_it_work;0.0.6",
                "fireworm;0.4.4",
                "minimatch;0.2.12",
                "lru-cache;2.3.1",
                "sigmund;1.0.0",
                "commander;1.3.2",
                "keypress;0.1.0",
                "express;3.4.0",
                "connect;2.9.0",
                "qs;0.6.5",
                "bytes;0.2.0",
                "pause;0.0.1",
                "uid2;0.0.2",
                "multiparty;2.1.8",
                "readable-stream;1.0.17",
                "stream-counter;0.1.0",
                "commander;1.2.0",
                "keypress;0.1.0",
                "range-parser;0.0.4",
                "mkdirp;0.3.5",
                "cookie;0.1.0",
                "buffer-crc32;0.2.1",
                "fresh;0.2.0",
                "methods;0.0.1",
                "send;0.1.4",
                "mime;1.2.11",
                "cookie-signature;1.0.1",
                "debug;0.7.3",
                "http-proxy;0.10.3",
                "colors;0.6.2",
                "optimist;0.3.7",
                "wordwrap;0.0.2",
                "pkginfo;0.2.3",
                "utile;0.1.7",
                "async;0.1.22",
                "deep-equal;0.1.0",
                "i;0.3.2",
                "mkdirp;0.3.5",
                "ncp;0.2.7",
                "rimraf;1.0.9",
                "coffee-script;1.6.3",
                "watch_r;0.0.14",
                "structr;0.3.2",
                "ejs;0.8.4",
                "underscore;1.4.4",
                "commander;1.1.1",
                "keypress;0.1.0",
                "async;0.2.9",
                "tq;0.2.5",
                "hurryup;0.0.2",
                "comerr;0.0.6",
                "semver;2.1.0",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_package_lock_json(json_schema):
    """Check package.json file output"""
    with open("tests/data/example_package_lock.json") as f:
        json_content = f.read()
    result = js_worker.handle_json(json_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [""],
            "pkg_name": "",
            "pkg_ver": "3.11.4",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "@f/zip-obj;1.1.1",
                "@paulcbetts/cld;github:ssbc/paulcbetts-cld-prebuilt#63609a21577c9c44229f16c0f42cf13322035718",
                "glob;5.0.15",
                "@paulcbetts/spellchecker;github:ssbc/paulcbetts-spellchecker-prebuilt"
                "#8e28e43d81073b354e7811792b9a39132db52221",
                "@types/node;8.10.39",
                "abbrev;1.1.1",
                "abstract-leveldown;4.0.3",
                "acorn;5.7.3",
                "acorn-dynamic-import;4.0.0",
                "acorn-jsx;3.0.1",
                "acorn;3.3.0",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_yarn_v1_lock(json_schema):
    """Check yarn.lock v1 file output"""
    with open("tests/data/example_v1_yarn.lock") as f:
        yarn_content = f.read()
    result = js_worker.handle_yarn_lock(yarn_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [],
            "pkg_name": "",
            "pkg_ver": "",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "@babel/code-frame;7.0.0-beta.55",
                "@babel/highlight;7.0.0-beta.55",
                "@gulp-sourcemaps/identity-map;1.0.2",
                "@gulp-sourcemaps/map-sources;1.0.0",
                "@zkochan/cmd-shim;3.1.0",
                "abab;1.0.4",
                "abab;2.0.0",
                "abbrev;1.1.1",
                "acorn-dynamic-import;2.0.2",
                "acorn-globals;4.1.0",
                "acorn-jsx;3.0.1",
                "acorn;5.7.1",
                "yargs;3.10.0",
                "yn;2.0.0",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_yarn_v2_lock(json_schema):
    """Check yarn.lock v2 file output"""
    with open("tests/data/example_v2_yarn.lock") as f:
        yarn_content = f.read()
    result = js_worker.handle_yarn_lock(yarn_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [],
            "pkg_name": "",
            "pkg_ver": "",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "@babel/code-frame;7.5.5",
                "@babel/core;7.6.0",
                "@babel/core;7.7.4",
                "@babel/generator;7.7.4",
                "@babel/helper-annotate-as-pure;7.7.4",
                "@babel/helper-builder-binary-assignment-operator-visitor;7.7.4",
                "@babel/helper-builder-react-jsx;7.7.4",
                "@babel/helper-call-delegate;7.7.4",
                "@babel/helper-create-class-features-plugin;7.7.4",
                "@babel/helper-create-regexp-features-plugin;7.7.4",
                "@babel/helper-define-map;7.7.4",
                "@babel/helper-explode-assignable-expression;7.7.4",
                "@babel/helper-function-name;7.7.4",
                "@babel/helper-get-function-arity;7.7.4",
                "@babel/helper-hoist-variables;7.7.4",
                "@babel/helper-member-expression-to-functions;7.7.4",
                "@babel/helper-module-imports;7.7.4",
                "@babel/helper-module-transforms;7.7.4",
                "@babel/helper-optimise-call-expression;7.7.4",
                "@babel/helper-plugin-utils;7.0.0",
                "@babel/helper-regex;7.5.5",
                "@babel/helper-remap-async-to-generator;7.7.4",
                "@babel/helper-replace-supers;7.7.4",
                "yarnv2-storybook;0.0.0-use.local",
                "@yarnpkg/parsers;0.0.0-use.local",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_requirements_txt(json_schema):
    """Check requirements.txt file output"""
    with open("tests/data/example_requirements.txt") as f:
        txt_content = f.read()
    result = py_helper.handle_requirements_txt(txt_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [],
            "pkg_name": "",
            "pkg_ver": "",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "cycler;>=0.10.0",
                "kiwisolver;>1.2.0",
                "matplotlib;<3.2.1",
                "numpy;!=1.18.5",
                "pandas;==1.*",
                "pyparsing;==2.*",
                "python-dateutil;==2.8.*",
                "pytz;==~2020",
                "scipy;==~1.4",
                "seaborn;==~0.10.1",
                "six;==^1.15.0",
                "beautifulsoup4;==^4.6",
                "certifi;==^2018",
                "chardet;==^0.0",
                "lxml;<5.7,>4",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_setup_py(json_schema):
    """Check setup.py file output"""
    with open("tests/data/example_setup.py") as f:
        py_content = f.read()
    result = py_worker.handle_setup_py(py_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "github",
            "lang_ver": [">=3.6"],
            "pkg_name": "PyGithub",
            "pkg_ver": "1.55",
            "pkg_lic": [
                "OSI Approved :: GNU Library or Lesser General Public License (LGPL)"
            ],
            "pkg_err": {},
            "pkg_dep": [],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_setup_cfg(json_schema):
    """Check setup.cfg file output"""
    with open("tests/data/example_setup.cfg") as f:
        cfg_content = f.read()
    result = py_worker.handle_setup_cfg(cfg_content)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [">= 2.7", " != 3.0.*", " != 3.1.*", " != 3.2.*"],
            "pkg_name": "{name}",
            "pkg_ver": "",
            "pkg_lic": ["MIT"],
            "pkg_err": {},
            "pkg_dep": ["setuptools;>=30.3.0"],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_pyproject_toml(json_schema):
    """Check toml file output"""
    with open("tests/data/example_pyproject.toml") as f:
        pyproject = f.read()
    result = py_worker.handle_toml(pyproject)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": ["2", "2.7", "3", "3.4", "3.5"],
            "pkg_name": "Django",
            "pkg_ver": "",
            "pkg_lic": ["BSD"],
            "pkg_err": {},
            "pkg_dep": ["numpy;>=1.18.5"],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_poetry_toml(json_schema):
    """Check poetry toml file output"""
    with open("tests/data/example_pyproject_poetry.toml") as f:
        pyproject = f.read()
    result = py_worker.handle_toml(pyproject)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [],
            "pkg_name": "language-service",
            "pkg_ver": "0.1.0",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "gunicorn;^20.0.4",
                "flask;^1.1.1",
                "flask_restful;^0.3.8",
                "spacy;^2.2.3",
                "thulac;^0.2.1",
                "wiktionaryparser;^0.0.97",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_other_py(json_schema):
    """
    Parses conda.yml tox.ini and Pipfiles
    """
    with open("tests/data/example_pipfile") as f:
        pyproject = f.read()
    result = py_worker.handle_otherpy(pyproject, "Pipfile")
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": [],
            "pkg_name": "",
            "pkg_ver": "",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": ["records;>0.5.0", "nose;"],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_cs_xml(json_schema):
    """Parses nuspec files"""
    with open("tests/data/example_package.nuspec") as f:
        nuspec = f.read()
    result = cs_worker.handle_nuspec(nuspec)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "lang_ver": [],
            "pkg_name": "Walter.Web.Firewall.Core.3.x",
            "pkg_ver": "2020.8.25.1",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "Walter.BOM;2020.8.25.1",
                "Microsoft.Extensions.Logging.Abstractions;3.1.7",
                "Microsoft.AspNetCore.Mvc.Core;2.2.5",
                "Microsoft.Extensions.Configuration.Binder;3.1.7",
                "Microsoft.Extensions.FileProviders.Physical;3.1.7",
                "Walter.Cypher;2020.8.23.1",
                "Microsoft.AspNetCore.Http.Features;3.1.7",
                "Microsoft.AspNetCore.Mvc.RazorPages;2.2.5",
                "Microsoft.Extensions.DependencyInjection.Abstractions;3.1.7",
                "Walter;2020.8.23.1",
                "Walter.Net.Networking;2020.8.25.1",
                "Walter.Web.FireWall.SqlDataTools;2020.8.25.1",
                "Newtonsoft.Json;12.0.3",
                "Microsoft.Extensions.Identity.Core;3.1.7",
                "Microsoft.AspNetCore.Routing;2.2.2",
                "Walter.Net.LookWhosTalking;2020.8.25.1",
                "Microsoft.Extensions.Caching.Abstractions;3.1.7",
                "System.Configuration.ConfigurationManager;4.7.0",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_composer_json(json_schema):
    """Check composer json file output"""
    with open("tests/data/example_composer.json") as f:
        php_project = f.read()
    result = php_worker.handle_composer_json(php_project)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "import_name": "",
            "lang_ver": ["^8.1"],
            "pkg_name": "sebastiaankloos/filament-code-editor",
            "pkg_ver": "",
            "pkg_lic": ["MIT"],
            "pkg_dep": [
                "filament/filament;^2.10",
                "illuminate/contracts;^9.0",
                "spatie/laravel-package-tools;^1.9.2",
            ],
            "pkg_err": {},
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_cargo_toml(json_schema):
    """Check cargo toml file output"""
    with open("tests/data/example_cargo.toml") as f:
        rust_project = f.read()
    result = rust_worker.handle_cargo_toml(rust_project)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "lang_ver": [],
            "pkg_name": "rustdesk",
            "pkg_ver": "1.1.8",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "whoami;1.2",
                "sys-locale;0.2",
                "serde_derive;1.0",
                "serde;1.0",
                "serde_json;1.0",
                "cfg-if;1.0",
                "lazy_static;1.4",
                "sha2;0.10",
                "repng;0.2",
                "libc;0.2",
                "parity-tokio-ipc;https://github.com/open-trade/parity-tokio-ipc||",
                "flexi_logger;0.22",
                "runas;0.2",
                "magnum-opus;https://github.com/open-trade/magnum-opus||",
                "async-trait;0.1",
                "crc32fast;1.3",
                "clap;3.0",
                "rpassword;6.0",
                "base64;0.13",
                "sysinfo;0.23",
                "num_cpus;1.13",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}


def test_cargo_lock(json_schema):
    """Check poetry toml file output"""
    with open("tests/data/example_cargo.lock") as f:
        rust_project = f.read()
    result = rust_worker.handle_lock(rust_project)
    assert json_schema.is_valid(result)
    ddiff = DeepDiff(
        result,
        {
            "lang_ver": [],
            "pkg_name": "",
            "pkg_ver": "",
            "pkg_lic": ["Other"],
            "pkg_err": {},
            "pkg_dep": [
                "addr2line;0.17.0",
                "adler;1.0.2",
                "adler32;1.2.0",
                "aho-corasick;0.7.18",
                "alsa;0.6.0",
                "alsa-sys;0.3.1",
                "android_log-sys;0.2.0",
                "android_logger;0.11.0",
                "ansi_term;0.12.1",
                "anyhow;1.0.56",
                "arboard;2.0.1",
                "async-trait;0.1.52",
                "atk;0.9.0",
                "atk-sys;0.10.0",
            ],
        },
        ignore_order=True,
        exclude_paths="root['timestamp']",
    )
    assert ddiff == {}
