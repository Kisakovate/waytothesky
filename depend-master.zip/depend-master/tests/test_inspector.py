"""Tests for all functions in inspector."""

from datetime import datetime

import httpx
import pytest
import pytest_asyncio

import depend.inspector as inspector
import depend.resolver
from depend.dependencies.dep_types import Result
from depend.error import LanguageNotSupportedError, VCSNotSupportedError


@pytest.fixture
def dependency_payload():
    """
    Generates a fixed payload to test the script
    :return: List of dependencies with language as key
    """
    return {
        "javascript": ["react;0.12.0"],
        "python": ["pygithub"],
        "go": [
            "https://github.com/go-yaml/yaml;https://github.com/go-yaml/yaml",
            "github.com/cactus/go-statsd-client/v5/statsd",
        ],
    }


@pytest.fixture
def result_payload():
    """
    Generates a result object to test the script
    :return: Result object to manipulate
    """
    result: Result = {
        "import_name": "",
        "lang_ver": [],
        "pkg_name": "",
        "pkg_ver": "",
        "pkg_lic": ["Other"],
        "pkg_err": {},
        "pkg_dep": [],
        "timestamp": datetime.utcnow().isoformat(),
    }
    return result


@pytest_asyncio.fixture
async def async_client():
    """
    Generates a result object to test the script
    :return: Result object to manipulate
    """
    limits = httpx.Limits(
        max_keepalive_connections=None, max_connections=None, keepalive_expiry=None
    )
    async with httpx.AsyncClient(follow_redirects=True, limits=limits) as client:
        yield client


def test_make_url_with_version():
    """Check if version specific url is generated for all languages"""
    assert (
        inspector.make_url("python", "aiohttp", "3.7.2")
        == "https://pypi.org/pypi/aiohttp/3.7.2/json"
    )
    assert (
        inspector.make_url("javascript", "diff", "5.0.0")
        == "https://registry.npmjs.org/diff/5.0.0"
    )
    assert (
        inspector.make_url("go", "bufio", "go1.17.6")
        == "https://pkg.go.dev/bufio@go1.17.6"
    )


def test_make_url_without_version():
    """Check if correct url is generated for all languages"""
    assert (
        inspector.make_url("python", "aiohttp") == "https://pypi.org/pypi/aiohttp/json"
    )
    assert inspector.make_url("javascript", "diff") == "https://registry.npmjs.org/diff"
    assert inspector.make_url("go", "bufio") == "https://pkg.go.dev/bufio"


@pytest.mark.asyncio
async def test_make_single_request_py(async_client):
    """Test version and license for python"""
    _, _, result = await depend.resolver.make_single_request(
        "python", "aiohttp", "3.7.2", client=async_client
    )
    assert result == ["3.7.2"]


@pytest.mark.asyncio
async def test_make_single_request_js(async_client):
    """Test version and license for javascript"""
    _, _, result = await depend.resolver.make_single_request(
        "javascript", "react", "17.0.2", client=async_client
    )
    assert result == ["17.0.2"]


@pytest.mark.asyncio
async def test_make_single_request_go(async_client):
    """Test version and license for go"""
    _, _, result = await depend.resolver.make_single_request(
        "go",
        "github.com/getsentry/sentry-go",
        "v0.12.0",
        client=async_client,
    )
    assert result == ["v0.12.0"]


@pytest.mark.asyncio
async def test_make_single_request_go_redirect(async_client):
    """Test version and license for go on redirects"""
    _, _, result = await depend.resolver.make_single_request(
        "go", "http", "go1.16.13", client=async_client
    )
    assert result == ["go1.16.13"]


@pytest.mark.asyncio
async def test_make_single_request_go_github(async_client):
    """Test version and license for go GitHub fallthrough"""
    _, _, result = await depend.resolver.make_single_request(
        "go", "gopkg.in/yaml.v3", "https://github.com/go-yaml/yaml", client=async_client
    )
    assert result


@pytest.mark.asyncio
async def test_make_single_request_rust(async_client):
    """Test version and license for javascript"""
    _, _, result = await depend.resolver.make_single_request(
        "rust", "reqrnpdno", client=async_client
    )
    assert result


@pytest.mark.asyncio
async def test_make_single_request_rust_ver(async_client):
    """Test version and license for javascript"""
    _, _, result = await depend.resolver.make_single_request(
        "rust", "picnic-sys", ">=3.0.14, <3.0.15", client=async_client
    )
    assert result == ["3.0.14"]


@pytest.mark.asyncio
async def test_make_single_request_rust_git(async_client):
    """Test version and license for javascript"""
    _, _, result = await depend.resolver.make_single_request(
        "rust",
        "sciter-rs",
        "https://github.com/open-trade/rust-sciter||dyn",
        client=async_client,
    )
    assert result


@pytest.mark.asyncio
async def test_make_multiple_requests(dependency_payload):
    """Multiple package requests for JavaScript NPM and Go"""
    result = [
        depend.resolver.make_multiple_requests(lang, dependencies, 1)
        for lang, dependencies in dependency_payload.items()
    ]
    assert len(result) == 3


@pytest.mark.asyncio
async def test_make_vcs_request(result_payload):
    """Test VCS handler"""
    inspector.handle_vcs("go", "github.com/getsentry/sentry-go", result_payload)
    assert result_payload["pkg_lic"] == ['BSD 2-Clause "Simplified" License']


@pytest.mark.asyncio
async def test_unsupported_language_fails():
    """Checks if exception is raised for unsupported language"""
    with pytest.raises(LanguageNotSupportedError, match="bhailang"):
        inspector.make_url("bhailang", "foo")


@pytest.mark.asyncio
async def test_unsupported_vcs_fails(result_payload):
    """Checks if exception is raised for unsupported pattern"""
    with pytest.raises(VCSNotSupportedError, match="gitlab"):
        inspector.handle_vcs("go", "gitlab.com/secmask/awserver", result_payload)


@pytest.mark.asyncio
async def test_make_single_request_cs(async_client):
    """Test version and license for c#"""
    _, _, result = await depend.resolver.make_single_request(
        "cs", "Microsoft.Bcl.AsyncInterfaces", client=async_client
    )
    assert result


@pytest.mark.asyncio
async def test_make_single_request_cs_ver(async_client):
    """Test version and license for c#"""
    _, _, result = await depend.resolver.make_single_request(
        "cs",
        "Walter.Web.Firewall.Core.3.x",
        "[2020.8.25.1[",
        client=async_client,
    )
    assert result == ["2020.8.25.1"]


@pytest.mark.asyncio
async def test_make_single_request_php(async_client):
    """Test version and license for php"""
    _, _, result = await depend.resolver.make_single_request(
        "php", "folospace/socketio", client=async_client
    )
    assert result


@pytest.mark.asyncio
async def test_make_single_request_php_ver(async_client):
    """Test version and license for php"""
    _, _, result = await depend.resolver.make_single_request(
        "php", "ajgarlag/psr15-dispatcher", "0.4.1", client=async_client
    )
    assert result == ["0.4.1"]
